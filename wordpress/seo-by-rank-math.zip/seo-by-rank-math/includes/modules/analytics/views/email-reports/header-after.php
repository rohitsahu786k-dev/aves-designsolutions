<?php
/**
 * Analytics Report header template.
 *
 * @package    RankMath
 * @subpackage RankMath\Admin
 */

use RankMath\Helper;

defined( 'ABSPATH' ) || exit;

?>
<div class="report-info">
	<div class="report-info-row">
		<h1><?php esc_html_e( 'SEO Report of Your Website', 'seo-by-rank-math' ); ?></h1>
		<a href="###SITE_URL###" target="_blank" class="site-url">###SITE_URL_SIMPLE###</a>
	</div>
	<div class="report-info-row report-meta-row">
		<h2 class="report-date">###START_DATE### - ###END_DATE###</h2>
		<div class="full-report-link">
			<a href="###REPORT_URL###" target="_blank">
				<?php esc_html_e( 'FULL REPORT', 'seo-by-rank-math' ); ?>
				<?php $this->image( 'report-icon-external.png', 12, 12, __( 'External Link Icon', 'seo-by-rank-math' ) ); ?>
			</a>
		</div>
	</div>
</div>

<?php if ( $this->get_variable( 'stats_invalid_data' ) ) { ?>
	<table role="presentation" border="0" cellpadding="0" cellspacing="0" class="report-error">
		<tr>
			<td>
				<h2><?php esc_html_e( 'Uh-oh', 'seo-by-rank-math' ); ?></h2>
				<p><em><?php esc_html_e( 'It seems that there are no stats to show right now.', 'seo-by-rank-math' ); ?></em></p>
				<?php // Translators: placeholders are anchor opening and closing tags. ?>
				<p><?php printf( esc_html__( 'If you can see the site data in your Search Console and Analytics accounts, but not here, then %1$s try reconnecting your account %2$s and make sure that the correct properties are selected in the %1$s Analytics Settings%2$s.', 'seo-by-rank-math' ), '<a href="' . esc_url( Helper::get_settings_url( 'general', 'analytics' ) ) . '">', '</a>' ); ?></p>
			</td>
		</tr>
	</table>
	<?php
}
